package com.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.oirs.bean.Requisition;
import com.oirs.bean.User;
import com.oirs.dbutil.DBConnector;
import com.oirs.dbutil.IQueryMapper;

public class DaoImpl implements IDao {

	@Override
	public boolean checkLogin(User user) {
		
		boolean b = false;
		Connection con=DBConnector.getConnected();
		
		
		try {
			PreparedStatement ps=con.prepareStatement(IQueryMapper.LOGIN_QUERY);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				b=true;
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		
		return b;
	}


	@Override
	public ArrayList<Requisition> showCurrentRequisition() {
		ArrayList<Requisition> reqList = new ArrayList<Requisition>();
		
		try {
			Connection con = DBConnector.getConnected();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(IQueryMapper.SELECT_OPEN_REQ);
			Requisition req = null;

			while (rs.next()) {
				req = new Requisition();
				req.setRequisitionId(rs.getString(1));
				req.setRMID(rs.getString(2));
				req.setProjectId(rs.getString(3));
				req.setDateCreated(rs.getString(4));
				req.setDateClosed(rs.getString(5));
				req.setCurrentStatus(rs.getString(6));
				req.setVacancyName(rs.getString(7));
				req.setSkill(rs.getString(8));
				req.setDomain(rs.getString(9));
				req.setNumberRequired(rs.getInt(10));
				reqList.add(req);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return reqList;
	}


	@Override
	public ArrayList<Requisition> showRequisitionHistory() {
		// TODO Auto-generated method stub
		return null;
	}


}
