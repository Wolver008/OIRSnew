package com.oirs.dao;

import java.util.ArrayList;

import com.oirs.bean.Requisition;
import com.oirs.bean.User;

public interface IDao {
	
	public boolean checkLogin(User user);
	public ArrayList<Requisition> showCurrentRequisition();

	public ArrayList<Requisition> showRequisitionHistory();


}
