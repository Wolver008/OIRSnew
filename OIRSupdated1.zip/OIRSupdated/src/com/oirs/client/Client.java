package com.oirs.client;

import java.util.Scanner;

import com.oirs.bean.Requisition;
import com.oirs.bean.User;
import com.oirs.service.IService;
import com.oirs.service.ServiceImpl;


public class Client {
	
	static Scanner scan;
	static int  loginStatus;
	
	public static void main(String[] args) {
		
		
		System.out.println("==============================================================================");
		System.out.println("****************** Online  Internal Requisition System ***********************");
		System.out.println("==============================================================================");
		System.out.println("Login As....");
		System.out.println("--> 1. Manager \n--> 2. Excecutive ");
		scan = new Scanner(System.in);
		int ch=scan.nextInt();
	switch(ch)
	{
	case 1:
	
		int a=login();
		if(a==0)
		{
			System.out.println("Invalid Credential");
		}
		else
		{
			managerLogin();
		}
		break;
		
	case 2:
		a=login();
		if(a==0)
		{
			System.out.println("Invalid Credential");
		}
		else
		{
			executiveLogin();
		}
		break;
	default:
		System.out.println("Plz Enter Correct Option : !!");
	}
	
  }
	public static int login()
	{
		IService service=new ServiceImpl();
		User user=new User();
		System.out.println("enter username");
		user.setUsername(scan.next());
		System.out.println("enter password");
		user.setPassword(scan.next());
		
		if(service.checkLogin(user))
		{
			loginStatus=1;
		}
		else
		{
			loginStatus=0;
			
		}
		return loginStatus;
	}
	public static void managerLogin()
	{
		System.out.println("\n\n-----Manager Dashboard-----\n\n");
		scan = new Scanner(System.in);
		System.out.println("--> 1. Raise Request \n--> 2. Track Requisition \n--> 3. Update Project Id. ");
		String input=scan.next();
		switch (input) {
		case "1":
			if(raiseRequisition())
			{
				System.out.println("Request Inserted");
			}
			else
			{
				System.out.println("Error Occurred");
				
			}
			break;
		case "2":
			trackRequisition();
			break;
		case "3":
			updateProjectId();
			break;
		default:
			break;
		}
	}
	private static void updateProjectId() 
	{
		scan = new Scanner(System.in);
		System.out.println("Enter Employee Id to ");
		String empId = scan.next();
	}
	private static void trackRequisition() {
		System.out.println("trackRequisition");
		
		scan=new Scanner(System.in);
		System.out.println("1. History \n2. Current Requisition");
		String input=scan.next();
		switch (input) {
		case "1":
				
				System.out.println("History");			
			break;
		case "2":
				System.out.println("Current Requisition");
			break;

		default:
			System.out.println("choose above option");
			break;
		}		
	}
	private static boolean raiseRequisition() {
		
		System.out.println("raiseRequisition");
		
		Requisition rb=new Requisition();
		scan=new Scanner(System.in);
		System.out.println("Enter Project ID :");
		rb.setProjectId(scan.next());
		System.out.println("Enter Vacancy Name :");
		rb.setVacancyName(scan.next());
		System.out.println("Enter Skill name :");
		rb.setSkill(scan.next());
		System.out.println("Enter domain name :");
		rb.setDomain(scan.next());
		System.out.println("Enter Number of Vacancy required :");
		rb.setNumberRequired(Integer.parseInt(scan.next()));
		
		
		
		
		return  setRequistion(rb);
		
	}
	private static boolean setRequistion(Requisition rb) {
		
		
		//carry object into service and then DAO
		
		return true;
	}
	public static void executiveLogin()
	{
		System.out.println("executiveLogin");
	}
	
	
	
	
	
	
}




