package com.oirs.bean;

public class ResourceManager
{
	private String RMID;
	private String name;
	private String projectId;
	
	public ResourceManager()
	{
		
	}
	
	public ResourceManager(String rMID, String name, String projectId) {
		RMID = rMID;
		this.name = name;
		this.projectId = projectId;
	}
	public String getRMID() {
		return RMID;
	}
	public void setRMID(String rMID) {
		RMID = rMID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	
	
}
