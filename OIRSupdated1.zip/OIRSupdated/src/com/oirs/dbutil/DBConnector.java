package com.oirs.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnector {
	
	public static Connection con;
	private static String url="jdbc:oracle:thin:@localhost:1521:xe";
	private static String user="system";
	private static String password="server";
	
	public static Connection getConnected() 
	{

		try 
		{
			
			con=DriverManager.getConnection(url, user, password);
			
		} catch (SQLException e)
		{
			e.printStackTrace();
			
		}
		return con;
	}

}
