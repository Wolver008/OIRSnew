package com.oirs.dbutil;

public interface IQueryMapper {
	
	public static final String LOGIN_QUERY="select user_id,password from user1 where user_id=? and password=?";
	public static final String SELECT_OPEN_REQ = "select * from requisition where curr_stat=?";
	

}
