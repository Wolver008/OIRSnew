package com.oirs.dbutil;

public interface IQueryMapper {
	
	public static final String LOGIN_QUERY="select user_id,password from user1 where user_id=? and password=?";
	public static final String SELECT_OPEN_REQ = "select * from requisition where curr_stat=?";
	public static final String PROJECT_ID = null;//select query--->SELECT Project_Id FROM dual
	public static final String STORE_DATA = null;//"INSERT INTO Requisition VALUES(?,?,?,?,?,?)";
	
    
}
