package com.oirs.dao;

import java.util.ArrayList;

import com.oirs.bean.Project;
import com.oirs.bean.Requisition;
import com.oirs.bean.User;

public interface IDao {
	
	public boolean checkLogin(User user);
	
	int storeData(Requisition r) ;
	
	public ArrayList<Requisition> showCurrentRequisition();

	public ArrayList<Requisition> showRequisitionHistory();


}
